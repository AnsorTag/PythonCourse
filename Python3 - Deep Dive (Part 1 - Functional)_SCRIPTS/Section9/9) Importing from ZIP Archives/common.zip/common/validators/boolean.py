# boolean.py

__all__ = ["is_boolean"]


def is_boolean(arg):
    pass


def boolean_helped_1():
    pass


def boolean_helped_2():
    pass
